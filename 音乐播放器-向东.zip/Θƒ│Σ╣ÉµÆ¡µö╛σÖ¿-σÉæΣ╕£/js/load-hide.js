  $(document).ready(function () {
      setTimeout(function () {
          $("#grid").hide();

      }, 2000);
  });