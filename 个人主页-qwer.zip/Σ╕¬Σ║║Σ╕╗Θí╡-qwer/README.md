# IPFS上的个人主页

## 项目名称

IPFS上的个人主页

## 项目概述

本项目演示了，在ipfs上托管一个 个人网站。IPFS 引入了一种用于内容的地址方案，无需大型中央服务器或内容分发网络，即可实现更健壮和分散的Web。

这是一个个人主页，经过散列并固定到本地 IPFS 节点，会得到如下的内容哈希：

QmUVj2fX8TUjzYPMybW6gjhz8FDgz3dqp9DtMUSGggAu3y

现在，其他人可以直接使用自己的 IPFS 客户端或使用可用的浏览器插件之一来检索网站。

这个地址就是目前网站所在的哈希地址

https://ipfs.io/ipfs/QmUVj2fX8TUjzYPMybW6gjhz8FDgz3dqp9DtMUSGggAu3y

网站可以实现视频播放的功能，视频也是被散列到了IPFS节点上。

## 团队成员昵称

qwer

## 联系方式

1095630061@qq.com

## 运行方式

1. 本地访问index.html即可访问主页
2. 访问ipfs散列后的地址，也可访问主页

