# Game2048

Game2048

## 项目概述

本项目是将IPFS节点，当作云端服务器，在上面托管了一个益智类2048小游戏，本地外的用户
可以访问哈希地址，体验该项目。

https://ipfs.io/ipfs/QmWkfK4mgEJoLQxpuGSjDXbNjcfLgMd1Q17JFUsx8UwcfD

近年来随着数据的增长，IPFS越来越凸显它的优势所在。去中心化的特点使得大型数据不在依赖于物理存储设备的限制。数据被散列成一个个碎片，使得数据更加的安全。

本项目只是IPFS开发的一个小小的尝试，如果未来有更多的IPFS应用落地，那势必会颠覆基于
HTTP协议的传统互联网。

## 团队成员昵称

冷风风

## 联系方式

lenggangjiao9036@163.com

## 访问方式

https://ipfs.io/ipfs/QmWkfK4mgEJoLQxpuGSjDXbNjcfLgMd1Q17JFUsx8UwcfD
