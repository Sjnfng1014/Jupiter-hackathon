# IPFS_Cloud

## 项目名称

IPFS_Cloud

## 项目概述

本项目基于IPFS开发了一款类似于百度网盘的应用，将个人的数据上传至IPFS节点，利用IPFS去中心化的特性，保证上传的数据不会丢失，不能被修改。

## 团队成员昵称

Xinstein

## 联系方式

Xinstein@icloud.com

## IPFS服务

本地实例化IPFS节点，使用[js-http-client](https://link.zhihu.com/?target=https%3A//github.com/ipfs-inactive/js-ipfs-http-client)与ipfs单节点进行交互。

点击上传文件，通过js-http-client将文件直接传进ipfs当中进行存储，返回存储的hash值，通过返回的hash值访问到上传的文件。支持图片、txt、音频等多种文件的上传。

## Project setup

```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

