
module.exports = {
    //重新定义路径，防止打包后页面空白
    publicPath:'./',
}