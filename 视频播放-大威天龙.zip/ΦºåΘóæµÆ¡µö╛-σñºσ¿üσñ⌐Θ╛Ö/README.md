# 基于IPFS的视频播放器

## 项目名称

Silisily

## 项目概述

本项目是基于IPFS服务的视频播放器，该播放器可以在线播放存储在IPFS节点上的视频文件，视频可以通过IPFS客户端上传到IPFS网络。

利用IPFS的特性，使得视频的上传和下载速度远远超过普通的HTTP协议，并且视频文件一旦上传
就不能被修改。

目前可用于测试的视频Hash有：
		QmWBbKvLhVnkryKG6F5YdkcnoVahwD7Qi3CeJeZgM6Tq68、
		QmQATmpxXvSiQgt9c9idz9k3S3gQnh7wYj4DbdMQ9VGyLh

该视频播放器具有网页全屏、全屏、画中画、倍速播放等基本功能

视频播放与IPFS的结合，必定是将来视频播放领域的一大突破。

## 团队成员昵称

大威天龙

## 联系方式

mujisong9339872752@163.com

## 运行方式

本地访问index.html即可访问主页

