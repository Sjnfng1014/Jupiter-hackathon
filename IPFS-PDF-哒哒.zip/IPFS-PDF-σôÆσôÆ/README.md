# 基于IPFS的PDF编辑器

## 项目名称

IPFS-PDF

## 项目概述

本项目基于IPFS，开发了一款PDF编辑器，PDF文件可以通过一系列的代码生成，在格式繁琐的地方，利用几行代码，就可以方便的控制。本项目旨在与强大的LaTex编辑器对标，并且与IPFS技术联系起来，做到上传、下载速度有保证，并且数据不被修改。

## 团队成员昵称

哒哒

## 联系方式

1482732977@qq.com

## IPFS应用

本地实例化IPFS节点，通过JS-Api与IPFS节点进行交互，完成文件的上传和下载。

点击上传按钮，通过API将PDF文件散列到IPFS节点上，并返回存储的hash值，通过返回的hash值访问到上传的文件。

## 项目运行

点击index.html文件，或者访问

https://ipfs.io/ipfs/QmVuodVNZ3j8usUcbq3JZQFgN8K7YPV1cA2xiL1pKiqRbU均可访问到项目首页。
